
  /$$$$$$                             /$$$$$$                      /$$       /$$                          
 /$$__  $$                           /$$__  $$                    | $$      | $$                          
| $$  \__/  /$$$$$$  /$$   /$$      | $$  \__/  /$$$$$$   /$$$$$$ | $$$$$$$ | $$$$$$$   /$$$$$$   /$$$$$$ 
|  $$$$$$  /$$__  $$| $$  | $$      | $$ /$$$$ /$$__  $$ |____  $$| $$__  $$| $$__  $$ /$$__  $$ /$$__  $$
 \____  $$| $$  \ $$| $$  | $$      | $$|_  $$| $$  \__/  /$$$$$$$| $$  \ $$| $$  \ $$| $$$$$$$$| $$  \__/
 /$$  \ $$| $$  | $$| $$  | $$      | $$  \ $$| $$       /$$__  $$| $$  | $$| $$  | $$| $$_____/| $$      
|  $$$$$$/| $$$$$$$/|  $$$$$$$      |  $$$$$$/| $$      |  $$$$$$$| $$$$$$$/| $$$$$$$/|  $$$$$$$| $$      
 \______/ | $$____/  \____  $$       \______/ |__/       \_______/|_______/ |_______/  \_______/|__/      
          | $$       /$$  | $$                                                                            
          | $$      |  $$$$$$/                                                                            
          |__/       \______/                                                                             





- start build.bat
- wait the full installation
- start Spy Grabber




Option	Description
Ping Me	Pings @everyone when someone runs the stub.
Anti VM	Tries its best to prevent the stub from running on Virtual Machine.
Put On Startup	Runs the stub on Windows starup.
Melt Stub	Deletes the stub after use.
Pump Stub	Pumps the stub upto the provided size.
Fake Error	Create custom (fake) error.
Block AV Sites	Blocks AV related sites (Unblock).
Discord Injection	Puts backdoor on the Discord client for persistence.
UAC Bypass	Tries to get administrator permissions without showing any prompt.


• GUI Builder.
• UAC Bypass.
• Custom Icon.
• Runs On Startup.
• Disables Windows Defender.
• Anti-VM.
• Blocks AV-Related Sites.
• Melt Stub.
• Fake Error.
• EXE Binder.
• File Pumper.
• Obfuscated Code.
• Discord Injection.
• Steals Discord Tokens.
• Steals Steam Session.
• Steals Epic Session.
• Steals Uplay Session.
• Steals Passwords From Many Browsers.
• Steals Cookies From Many Browsers.
• Steals History From Many Browsers.
• Steals Autofills From Many Browsers.
• Steals Minecraft Session Files.
• Steals Telegram Session Files.
• Steals Crypto Wallets.
• Steals Roblox Cookies.
• Steals Growtopia Session.
• Steals IP Information.
• Steals System Info.
• Steals Saved Wifi Passwords.
• Steals Common Files.
• Captures Screenshot.
• Captures Webcam Image.
• Sends All Data Through Discord Webhooks/Telegram Bot.
(...more)